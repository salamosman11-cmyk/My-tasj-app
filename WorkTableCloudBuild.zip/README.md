# WorkTable Android

بەرنامەی خشتەی کارەکان:
- ژمارە / خاوەنکار / جۆری کار / شوێنی کار / دۆنم / نرخ / کۆی گشتی
- Search بە ناوی خاوەنکار
- هەژمارکردنی ئۆتۆماتیکی: دۆنم × نرخ
- زیادکردن و دەستکاریکردنی تۆمار
- هەڵگرتنی داتا لەسەر مۆبایل

## Cloud Build
ئەم پڕۆژەیە Android Gradle Project ـە. ZIP ـەکە unpack بکە و بە GitHub/Cloud Android builder ـەکەت upload بکە.
Build task:
`assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
