package com.worktable.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout table, header;
    EditText search;
    TextView total;
    ArrayList<Job> jobs = new ArrayList<>();
    android.content.SharedPreferences prefs;

    static class Job {
        String owner, type, place;
        double donum, rate;
        Job(String o,String t,String p,double d,double r){owner=o;type=t;place=p;donum=d;rate=r;}
        double sum(){return donum*rate;}
        JSONObject json() throws JSONException {
            JSONObject x=new JSONObject();
            x.put("owner",owner); x.put("type",type); x.put("place",place);
            x.put("donum",donum); x.put("rate",rate); return x;
        }
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        table=findViewById(R.id.table); header=findViewById(R.id.header);
        search=findViewById(R.id.search); total=findViewById(R.id.total);
        prefs=getSharedPreferences("jobs",MODE_PRIVATE);
        load();
        buildHeader();
        render("");
        findViewById(R.id.add).setOnClickListener(v -> showAddDialog());
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){render(s.toString().trim());}
            public void afterTextChanged(Editable e){}
        });
    }

    TextView cell(String text, int width){
        TextView v=new TextView(this);
        v.setText(text); v.setTextSize(15); v.setTextColor(Color.DKGRAY);
        v.setGravity(Gravity.CENTER); v.setPadding(10,12,10,12);
        v.setBackgroundColor(Color.WHITE);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(width),-2));
        return v;
    }
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}

    void buildHeader(){
        header.removeAllViews();
        String[] h={"ژمارە","خاوەنکار","جۆری کار","شوێنی کار","دۆنم","نرخ","کۆی گشتی"};
        int[] w={60,150,130,150,80,120,130};
        for(int i=0;i<h.length;i++){
            TextView v=cell(h[i],w[i]); v.setTextColor(Color.rgb(18,59,102));
            v.setTextSize(14); v.setTypeface(null,1); header.addView(v);
        }
    }

    void render(String q){
        table.removeAllViews();
        double grand=0; int n=0;
        for(int i=0;i<jobs.size();i++){
            Job j=jobs.get(i);
            if(!q.isEmpty() && !j.owner.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))) continue;
            n++; grand+=j.sum();
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            String[] vals={String.valueOf(n),j.owner,j.type,j.place,fmt(j.donum),fmt(j.rate),fmt(j.sum())};
            int[] w={60,150,130,150,80,120,130};
            for(int k=0;k<vals.length;k++) row.addView(cell(vals[k],w[k]));
            row.setOnLongClickListener(v -> { showEditDialog(j); return true; });
            table.addView(row);
        }
        total.setText("کۆی گشتی: "+fmt(grand)+"    |    ژمارەی کارەکان: "+n);
    }

    String fmt(double x){
        if(x==Math.rint(x)) return String.format(Locale.US,"%.0f",x);
        return String.format(Locale.US,"%.2f",x);
    }

    void showAddDialog(){ showForm(null); }
    void showEditDialog(Job j){ showForm(j); }

    void showForm(Job edit){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),0,dp(16),0);
        EditText owner=in("خاوەنکار"); EditText type=in("جۆری کار"); EditText place=in("شوێنی کار");
        EditText donum=in("دۆنم (ژمارە)"); EditText rate=in("نرخ بۆ هەر دۆنم");
        donum.setInputType(2|8192); rate.setInputType(2|8192);
        box.addView(owner);box.addView(type);box.addView(place);box.addView(donum);box.addView(rate);
        if(edit!=null){owner.setText(edit.owner);type.setText(edit.type);place.setText(edit.place);donum.setText(fmt(edit.donum));rate.setText(fmt(edit.rate));}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(edit==null?"زیادکردنی کاری نوێ":"دەستکاریکردن")
            .setView(box).setNegativeButton("پاشگەزبوونەوە",null)
            .setPositiveButton("هەڵگرتن",null).create();
        d.setOnShowListener(x -> d.getButton(-1).setOnClickListener(v -> {
            try{
                String o=owner.getText().toString().trim(), t=type.getText().toString().trim(), p=place.getText().toString().trim();
                double dn=Double.parseDouble(donum.getText().toString().trim()), r=Double.parseDouble(rate.getText().toString().trim());
                if(o.isEmpty()) throw new Exception();
                if(edit==null) jobs.add(new Job(o,t,p,dn,r));
                else {edit.owner=o;edit.type=t;edit.place=p;edit.donum=dn;edit.rate=r;}
                save(); render(search.getText().toString().trim()); d.dismiss();
            }catch(Exception e){Toast.makeText(this,"تکایە هەموو زانیارییەکان بە دروستی بنووسە",Toast.LENGTH_SHORT).show();}
        }));
        d.show();
    }

    EditText in(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setPadding(0,dp(8),0,dp(8)); return e; }

    void save(){
        JSONArray a=new JSONArray();
        try{for(Job j:jobs)a.put(j.json());}catch(Exception ignored){}
        prefs.edit().putString("data",a.toString()).apply();
    }
    void load(){
        try{
            JSONArray a=new JSONArray(prefs.getString("data","[]"));
            for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);
                jobs.add(new Job(x.optString("owner"),x.optString("type"),x.optString("place"),x.optDouble("donum"),x.optDouble("rate")));
            }
        }catch(Exception ignored){}
    }
}
