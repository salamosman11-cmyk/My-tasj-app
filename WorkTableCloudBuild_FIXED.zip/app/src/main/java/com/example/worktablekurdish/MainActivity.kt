package com.example.worktablekurdish

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Work(val id:Int, var owner:String, var place:String, var area:String, var type:String, var date:String, var price:String)

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private val prefs by lazy { getSharedPreferences("works", Context.MODE_PRIVATE) }
    private var works = mutableListOf<Work>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
        render()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "خشتەی کارەکان"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0,0,0,18)
        }
        root.addView(title)

        search = EditText(this).apply {
            hint = "گەڕان بە ناو، شوێن، جۆری کار یان ژمارە..."
            textSize = 16f
            singleLine = true
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2))
        search.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?, st:Int,b:Int,c:Int){ render() }
            override fun afterTextChanged(e:android.text.Editable?){}
        })

        val add = Button(this).apply {
            text = "➕ کاری نوێ زیاد بکە"
            setOnClickListener { showEditor(null) }
        }
        root.addView(add)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(list)

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        works.filter {
            q.isEmpty() || "${it.id} ${it.owner} ${it.place} ${it.area} ${it.type} ${it.date} ${it.price}".lowercase().contains(q)
        }.forEach { w ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18,18,18,18)
                setBackgroundColor(Color.rgb(245,245,245))
            }
            val tv = TextView(this).apply {
                text = "ژمارە: ${w.id}\nخاوەنکار: ${w.owner}\nشوێن: ${w.place}\nڕووبەر: ${w.area}\nجۆری کار: ${w.type}\nبەروار: ${w.date}\nنرخ: ${w.price}"
                textSize = 17f
                setPadding(0,0,0,10)
            }
            card.addView(tv)
            val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER }
            val edit = Button(this).apply { text="✏️ دەستکاری"; setOnClickListener{showEditor(w)} }
            val del = Button(this).apply { text="🗑️ سڕینەوە"; setOnClickListener{
                works.remove(w); save(); render()
            }}
            buttons.addView(edit); buttons.addView(del)
            card.addView(buttons)
            list.addView(card, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,12,0,0)})
        }
    }

    private fun showEditor(existing: Work?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30,10,30,10)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val fields = listOf("ناوی خاوەنکار","شوێنی کار","ڕووبەر","جۆری کار","بەروار","نرخ")
        val inputs = fields.map { label ->
            EditText(this).apply { hint=label; textSize=17f; singleLine=true; layoutDirection=View.LAYOUT_DIRECTION_RTL }
        }
        if(existing!=null) {
            inputs[0].setText(existing.owner); inputs[1].setText(existing.place); inputs[2].setText(existing.area)
            inputs[3].setText(existing.type); inputs[4].setText(existing.date); inputs[5].setText(existing.price)
        }
        inputs.forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle(if(existing==null) "کاری نوێ" else "دەستکاری کار")
            .setView(box).setPositiveButton("خەزن") { _,_ ->
                if(existing==null) {
                    val next = (works.maxOfOrNull{it.id} ?: 0)+1
                    works.add(Work(next,*inputs.map{it.text.toString()}.toTypedArray()))
                } else {
                    existing.owner=inputs[0].text.toString(); existing.place=inputs[1].text.toString()
                    existing.area=inputs[2].text.toString(); existing.type=inputs[3].text.toString()
                    existing.date=inputs[4].text.toString(); existing.price=inputs[5].text.toString()
                }
                save(); render()
            }.setNegativeButton("پاشگەزبوون", null).show()
    }

    private fun save() {
        val arr=JSONArray()
        works.forEach { w -> arr.put(JSONObject().apply {
            put("id",w.id); put("owner",w.owner); put("place",w.place); put("area",w.area)
            put("type",w.type); put("date",w.date); put("price",w.price)
        })}
        prefs.edit().putString("data",arr.toString()).apply()
    }

    private fun load() {
        val arr=JSONArray(prefs.getString("data","[]"))
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i)
            works.add(Work(o.getInt("id"),o.getString("owner"),o.getString("place"),
                o.getString("area"),o.getString("type"),o.getString("date"),o.getString("price")))
        }
    }
}
