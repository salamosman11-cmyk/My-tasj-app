# خشتەی کارەکان — Cloud Build
پڕۆژەی Android بۆ تۆمارکردنی کارەکان.
Build:
- لە Android Studio: Build > Generate App Bundle / APK > Generate APK
- یان لە GitHub Actions: workflow ی `.github/workflows/build-apk.yml` بەکاردێت.
